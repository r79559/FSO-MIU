// Susan R. Miller
// MiU 1304
// Week 1
//

var json = {

	"chore1": {
		"chore": ["Chore Name: ", "Water plants"],
		"who": ["Person Responsible: ", "Mom"],
		"date": ["Date Due ", "05/01/2013"],
		"effort": ["Level of Difficulty: ", "4"],
		"done": ["Is it Done? ", "Not Yet"]
	},

	"chore2": {
		"chore": ["Chore Name: ", "Polish trophy"],
		"who": ["Person Responsible: ", "Papa"],
		"date": ["Date Due ", "05/8/2013"],
		"effort": ["Level of Difficulty: ", "3"],
		"done": ["Is it Done? ", "Not Yet"]
	},

	"chore3": {
		"chore": ["Chore Name: ", "Feed dogs"],
		"who": ["Person Responsible: ", "Daughter A"],
		"date": ["Date Due ", "04/15/2013"],
		"effort": ["Level of Difficulty: ", "2"],
		"done": ["Is it Done? ", "Not Yet"]
	},

	"chore4": {
		"chore": ["Chore Name: ", "Take out trash"],
		"who": ["Person Responsible: ", "Anyone"],
		"date": ["Date Due ", "04/30/2013"],
		"effort": ["Level of Difficulty: ", "5"],
		"done": ["Is it Done? ", "Not Yet"]
	},

	"chore5": {
		"chore": ["Chore Name: ", "Vacuum"],
		"who": ["Person Responsible: ", "Mom"],
		"date": ["Date Due ", "04/20/2013"],
		"effort": ["Level of Difficulty: ", "6"],
		"done": ["Is it Done? ", "Not Yet"]
	},

	"chore6": {
		"chore": ["Chore Name: ", "Dust downstairs"],
		"who": ["Person Responsible: ", "Mom"],
		"date": ["Date Due ", "04/11/2013"],
		"effort": ["Level of Difficulty: ", "7"],
		"done": ["Is it Done? ", "Not Yet"]
	},

	"chore7": {
		"chore": ["Chore Name: ", "Dust upstairs"],
		"who": ["Person Responsible: ", "Daughter B"],
		"date": ["Date Due ", "05/3/2013"],
		"effort": ["Level of Difficulty: ", "7"],
		"done": ["Is it Done? ", "Not Yet"]
	},

	"chore8": {
		"chore": ["Chore Name: ", "Clean playroom"],
		"who": ["Person Responsible: ", "Daughter A"],
		"date": ["Date Due ", "04/23/2013"],
		"effort": ["Level of Difficulty: ", "8"],
		"done": ["Is it Done? ", "Not Yet"]
	},

	"chore9": {
		"chore": ["Chore Name: ", "Clean bedroom"],
		"who": ["Person Responsible: ", "Daughter B"],
		"date": ["Date Due ", "04/25/2013"],
		"effort": ["Level of Difficulty: ", "9"],
		"done": ["Is it Done? ", "Not Yet"]
	},

	"chore10": {
		"chore": ["Chore Name: ", "Make bed"],
		"who": ["Person Responsible: ", "Daughter A"],
		"date": ["Date Due ", "04/9/2013"],
		"effort": ["Level of Difficulty: ", "2"],
		"done": ["Is it Done? ", "Not Yet"]
	},

	"chore11": {
		"chore": ["Chore Name: ", "Clean off DVR"],
		"who": ["Person Responsible: ", "Papa"],
		"date": ["Date Due ", "04/12/2013"],
		"effort": ["Level of Difficulty: ", "6"],
		"done": ["Is it Done? ", "Not Yet"]
	},

	"chore12": {
		"chore": ["Chore Name: ", "Commit to Git"],
		"who": ["Person Responsible: ", "Mom"],
		"date": ["Date Due ", "04/8/2013"],
		"effort": ["Level of Difficulty: ", "2"],
		"done": ["Is it Done? ", "Not Yet"]
	},

	"chore13": {
		"chore": ["Chore Name: ", "Backup data"],
		"who": ["Person Responsible: ", "Papa"],
		"date": ["Date Due ", "04/14/2013"],
		"effort": ["Level of Difficulty: ", "8"],
		"done": ["Is it Done? ", "Not Yet"]
	},

	"chore14": {
		"chore": ["Chore Name: ", "Gather yard sale stuff"],
		"who": ["Person Responsible: ", "Anyone"],
		"date": ["Date Due ", "04/30/2013"],
		"effort": ["Level of Difficulty: ", "9"],
		"done": ["Is it Done? ", "Not Yet"]
	},

	"chore15": {
		"chore": ["Chore Name: ", "Take recycling"],
		"who": ["Person Responsible: ", "Papa"],
		"date": ["Date Due ", "04/17/2013"],
		"effort": ["Level of Difficulty: ", "3"],
		"done": ["Is it Done? ", "Not Yet"]
	},

	"chore16": {
		"chore": ["Chore Name: ", "Homework"],
		"who": ["Person Responsible: ", "Daughter A"],
		"date": ["Date Due ", "04/10/2013"],
		"effort": ["Level of Difficulty: ", "4"],
		"done": ["Is it Done? ", "Not Yet"]
	},

	"chore17": {
		"chore": ["Chore Name: ", "RUN!"],
		"who": ["Person Responsible: ", "Mom"],
		"date": ["Date Due ", "04/10/2013"],
		"effort": ["Level of Difficulty: ", "10"],
		"done": ["Is it Done? ", "Not Yet"]
	},

	"chore18": {
		"chore": ["Chore Name: ", "Catch up on The Walking Dead"],
		"who": ["Person Responsible: ", "Mom"],
		"date": ["Date Due ", "05/6/2013"],
		"effort": ["Level of Difficulty: ", "1"],
		"done": ["Is it Done? ", "Not Yet"]
	},

	"chore19": {
		"chore": ["Chore Name: ", "Confirm appointments"],
		"who": ["Person Responsible: ", "Mom"],
		"date": ["Date Due ", "04/22/2013"],
		"effort": ["Level of Difficulty: ", "5"],
		"done": ["Is it Done? ", "Not Yet"]
	},

	"chore20": {
		"chore": ["Chore Name: ", "Meditate"],
		"who": ["Person Responsible: ", "Daughter B"],
		"date": ["Date Due ", "04/10/2013"],
		"effort": ["Level of Difficulty: ", "1"],
		"done": ["Is it Done? ", "Not Yet"]
	}

}


